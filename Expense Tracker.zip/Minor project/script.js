
let expenses = [];

let income =
localStorage.getItem("income") || 0;

document.getElementById("income-display")
.innerText = income;



async function loadExpenses(){

    let response =
    await fetch(
    "http://localhost:5000/expenses"
    );

    expenses =
    await response.json();

    displayExpenses();
}



function setIncome(){

    income =
    Number(
    document.getElementById("income").value
    );

    localStorage.setItem("income", income);

    document.getElementById("income-display")
    .innerText = income;

    displayExpenses();

    document.getElementById("income").value = "";
}



function displayExpenses(){

    let total =
    document.getElementById("total");

    let balance =
    document.getElementById("balance");

    let totalExpense = 0;

    expenses.forEach(expense => {

        totalExpense +=
        Number(expense.amount);

    });

    total.innerText =
    totalExpense;

    let remainingBalance =
    income - totalExpense;

    if(remainingBalance < 0){

        balance.innerText =
        "Insufficient Balance";

    }

    else{

        balance.innerText =
        remainingBalance;

    }

}



async function addExpense(){

    let title =
    document.getElementById("title").value;

    let amount =
    document.getElementById("amount").value;

    let category =
    document.getElementById("category").value;

    let date =
    document.getElementById("date").value;

    if(title === "" ||
       amount === "" ||
       date === ""){

        alert("Please Fill All Fields");

        return;

    }



    await fetch(

    "http://localhost:5000/add",

    {

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body: JSON.stringify({

            title,
            amount,
            category,
            date

        })

    });




    await loadExpenses();



    document.getElementById("title").value = "";

    document.getElementById("amount").value = "";

    document.getElementById("date").value = "";

    alert("Expense Added");

}



async function resetData(){

    try{

        await fetch(

        "http://localhost:5000/reset",

        {
            method:"DELETE"
        });

        expenses = [];

        income = 0;

        localStorage.clear();

        document.getElementById("income-display")
        .innerText = 0;

        document.getElementById("total")
        .innerText = 0;

        document.getElementById("balance")
        .innerText = 0;

        alert("All Data Reset Successfully");

        location.reload();

    }

    catch(error){

        console.log(error);

        alert("Reset Failed");

    }

}

loadExpenses();

