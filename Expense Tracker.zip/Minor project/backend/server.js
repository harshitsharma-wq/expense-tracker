
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();

app.use(cors());

app.use(express.json());

mongoose.connect(
"mongodb://127.0.0.1:27017/expenseTracker"
)

.then(()=>{

    console.log("MongoDB Connected");

})

.catch((error)=>{

    console.log(error);

});

const ExpenseSchema = new mongoose.Schema({

    title: String,

    amount: Number,

    category: String,

    date: String

});

const Expense =
mongoose.model("Expense", ExpenseSchema);



app.post("/add", async(req,res)=>{

    try{

        const expense =
        new Expense(req.body);

        await expense.save();

        res.send("Expense Added");

    }

    catch(error){

        console.log(error);

    }

});



app.get("/expenses", async(req,res)=>{

    try{

        const expenses =
        await Expense.find();

        res.json(expenses);

    }

    catch(error){

        console.log(error);

    }

});



app.delete("/reset", async(req,res)=>{

    try{

        await Expense.collection.deleteMany({});

        res.send("Database Reset Successful");

    }

    catch(error){

        console.log(error);

    }

});



app.listen(5000, ()=>{

    console.log("Server Running");

});

